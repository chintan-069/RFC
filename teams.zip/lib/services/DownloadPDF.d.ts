import { SPFI } from "@pnp/sp";
import "@pnp/sp/files";
import "@pnp/sp/folders";
declare const DownloadFileFromSharepointLibrary: (sp: SPFI, context: any, libraryName: string, fileName: string) => Promise<void>;
export default DownloadFileFromSharepointLibrary;
//# sourceMappingURL=DownloadPDF.d.ts.map