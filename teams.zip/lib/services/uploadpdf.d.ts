declare const fetchPdf: (libname: any, context: any, filename: any) => Promise<void>;
export default fetchPdf;
//# sourceMappingURL=uploadpdf.d.ts.map