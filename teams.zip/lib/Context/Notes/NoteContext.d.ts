import * as React from 'react';
import { ReactNode, Dispatch, SetStateAction } from 'react';
export interface FirstPageData {
    name: string;
    email: string;
    calendar: string;
}
export interface WI4 {
    getimageWI4: string;
}
export interface I_9 {
    getimageI_9: string;
}
export interface Policy {
    getimagePolicy: string;
}
export interface registration {
    fullName: string;
    address: string;
    city: string;
    state: string;
    zip: string;
    emailAddress: string;
    primaryPhone: string;
    altPhone: string;
    dateOfBirth: string | Date;
    socSec: string;
    MorS: string;
    dependents: string;
    emrContactname: string;
    emrContact: string;
    relationship: string;
    local: string;
    wage: string;
    term: string;
    dateofHire: string;
    eVarifyDate: string;
    number: string;
}
export interface ThankyouPageData {
    total: number;
}
export interface FormData {
    WI4: WI4;
    I_9: I_9;
    Policy: Policy;
    registration: registration;
}
export default interface FormContextType {
    formData: FormData;
    setFormData: Dispatch<SetStateAction<FormData>>;
}
interface FormProviderProps {
    children: ReactNode;
}
export declare const FormProvider: React.FC<FormProviderProps>;
export declare const useFormContext: () => FormContextType;
export {};
//# sourceMappingURL=NoteContext.d.ts.map