import * as React from 'react';
interface SecondPageProps {
    onNext: () => void;
    onPrevious: () => void;
    context: any;
}
declare const Policy: React.FC<SecondPageProps>;
export default Policy;
//# sourceMappingURL=Policy.d.ts.map