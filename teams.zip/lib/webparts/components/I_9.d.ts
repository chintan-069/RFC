import * as React from 'react';
interface SecondPageProps {
    onNext: () => void;
    onPrevious: () => void;
    context: any;
}
declare const I_9: React.FC<SecondPageProps>;
export default I_9;
//# sourceMappingURL=I_9.d.ts.map