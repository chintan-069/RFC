/// <reference types="react" />
declare const Registration: ({ onNext, _sp }: {
    onNext: () => void;
    _sp: any;
}) => JSX.Element;
export default Registration;
//# sourceMappingURL=Registration.d.ts.map