import * as React from 'react';
interface SecondPageProps {
    onNext: () => void;
    onPrevious: () => void;
    context: any;
    _sp: any;
}
declare const WI4: React.FC<SecondPageProps>;
export default WI4;
//# sourceMappingURL=WI4.d.ts.map