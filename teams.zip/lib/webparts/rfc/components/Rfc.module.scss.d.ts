declare const styles: {
    rfc: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    officeUse: string;
    edate: string;
    margin20: string;
    links: string;
    width100: string;
};
export default styles;
//# sourceMappingURL=Rfc.module.scss.d.ts.map