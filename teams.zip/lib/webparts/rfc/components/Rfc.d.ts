/// <reference types="react" />
declare const Rfc: (props: any) => JSX.Element;
export default Rfc;
//# sourceMappingURL=Rfc.d.ts.map