/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable @typescript-eslint/no-explicit-any */
import * as React from 'react';
// import styles from './Rfc.module.scss';
import { PrimaryButton } from '@fluentui/react';
import Registration from '../../components/Registration';
import I_9 from '../../components/I_9';
import Policy from '../../components/Policy';
import WI4 from '../../components/WI4';
// import WI4 from '../../components/WI4';
// import Policy from '../../components/Policy';

const Rfc = (props: any) => {


  const [currentStep, setCurrentStep] = React.useState<number>(0);


  // const get = async () => {
  //   // const items: any[] = await props._sp.web.lists.getByTitle("Student").items();
  //   const items: any[] = await props._sp.web.lists.getByTitle("Feedbck_List").items();

  //   console.log(items);
  // }
  // // console.log(typeof(props._sp));


  // React.useEffect(() => {
  //   get().catch(err => console.log(err));
  //   // post().catch(err => console.log(err));
  //   // updateItem().catch((err: any) => console.log(err))
  // }, []);

  const handleNextClick = () => {
    setCurrentStep(currentStep + 1);

  };

  const handlePreviousClick = () => {
    setCurrentStep(currentStep - 1);
  }

  const renderContent = () => {
    switch (currentStep) {
      case 0:
        return <WI4 onNext={handleNextClick} onPrevious={handlePreviousClick} context={props.context} _sp={props._sp} />;
      case 1:
        return <><Registration onNext={handleNextClick} _sp={props._sp} /> </>;
      case 2:
        return <I_9 onNext={handleNextClick} onPrevious={handlePreviousClick} context={props.context} />;
      case 3:
        return <Policy onPrevious={handlePreviousClick} onNext={handleNextClick} context={props.context} />;
      // case 4:
      // return <Thankyou />;

      default:
        return null;
    }
  };

  const isButtonEnabled = (step: number) => {
    return currentStep === step;
  };


  return (
    <section>

      <div>
        <div>

          <PrimaryButton disabled={!isButtonEnabled(0)} onClick={() => setCurrentStep(0)}>Tab 1</PrimaryButton>
          <PrimaryButton disabled={!isButtonEnabled(1)} onClick={() => setCurrentStep(1)}>Tab 2</PrimaryButton>
          <PrimaryButton disabled={!isButtonEnabled(2)} onClick={() => setCurrentStep(2)}>Tab 3</PrimaryButton>
          <PrimaryButton disabled={!isButtonEnabled(3)} onClick={() => setCurrentStep(3)}>Tab 4</PrimaryButton>
        </div>

        <div>
          <h3 style={{ paddingLeft: '140px' }}> Tell us about your self</h3>

        </div>
        <div>
          <div>
            {renderContent()}
          </div>


        </div>
      </div>
    </section>
  );
}

export default Rfc
