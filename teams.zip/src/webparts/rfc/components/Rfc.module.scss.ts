/* tslint:disable */
require("./Rfc.module.css");
const styles = {
  rfc: 'rfc_edf550e3',
  teams: 'teams_edf550e3',
  welcome: 'welcome_edf550e3',
  welcomeImage: 'welcomeImage_edf550e3',
  officeUse: 'officeUse_edf550e3',
  edate: 'edate_edf550e3',
  margin20: 'margin20_edf550e3',
  links: 'links_edf550e3',
  width100: 'width100_edf550e3'
};

export default styles;
/* tslint:enable */