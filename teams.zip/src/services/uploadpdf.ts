/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { SPHttpClient } from '@microsoft/sp-http';

const fetchPdf = async (libname:any, context : any, filename : any) => {
    console.log(libname);
            const spopts = {
                headers: {
                    "Accept": "application/json",
                    "Content-Type":"application/json"
                },
                body: libname
              }
  
          const url = `${context.pageContext.web.absoluteUrl}/_api/Web/Lists/getByTitle('${libname}')/RootFolder/Files/Add(url='${filename}.pdf',overwrite=true)`;
          // root folder ma folder banain karva..
          // cons url = `${context.pageContext.web.absoluteUrl}/_api/Web/Lists/getByTitle('Documents')/RootFolder/Folders('WI4')/Files/Add(url='Abcsd.pdf',overwrite=true)`;

          try {
              const response = await context.spHttpClient.post(url, SPHttpClient.configurations.v1, spopts);
              const responseJSON = await response.json();
              console.log(responseJSON.Name);
          } catch (err) {
              console.error("Error uploading file: ", err);
            //   setUploadError('Error uploading file. Check console for details.');
          }

        }

export default fetchPdf;